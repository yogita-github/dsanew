package com.demo.service;

public interface Service {
    void addEmployee();

    void sortEmployee();
}
