package hashList2;


import hashTable.LinkedList;

public class HashLinkedList {
    public void displayList() {
        if (head == null) {
            return;
        }
            Node temp = head;
            while (temp != null) {
                System.out.println(temp.data);
                temp = temp.next;

        }
    }

    class Node {
        int data;
        Node next;

        public Node(int val) {
            this.data = val;
            this.next = null;
        }
    }

    Node head;

    public HashLinkedList() {
        this.head = null;
    }

    public void add(int val) {
        Node newnode = new Node(val);
        if (head == null) {
            head = newnode;
        } else {
            newnode.next = head;
            head = newnode;
        }
    }

    public boolean searchValue(int val) {
        if (head == null) {
            System.out.println("List is empty");
        }else{
            Node temp = head;
            while(temp!=null && temp.data!=val){
                System.out.println(temp.data);
                temp = temp.next;
            }
        }
        return false;
    }
    public boolean delete(int v){
        Node temp=head;
        if(head==null){
            System.out.println("list is emtpy");
            return false;
        }else if(head!=null){
            if(head.data==v){
                temp = temp.next;
                head = null;
            }else{
                Node prev = null;
                while(temp!=null && temp.data!=v){
                    prev=temp;
                    temp= temp.next;
                    return false;
                }
                if(temp.data==v){
                    prev.next=temp.next;
                    temp.next=null;
                    temp=null;
                }

            }

        }
        return true;
    }
}
