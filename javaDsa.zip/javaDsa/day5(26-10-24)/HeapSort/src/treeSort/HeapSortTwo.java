package treeSort;

import java.util.Arrays;

public class HeapSortTwo {
    public static void main(String[] args) {
        int[] arr={1,6,8,3,2,5,8,9};
        System.out.println("Before Sorting : ");
        System.out.println(Arrays.toString(arr));
        heapsort(arr);
        System.out.println("After Sorting : ");
        System.out.println(Arrays.toString(arr));
    }
    private static void heapsort(int[] a){
        int n = a.length;
        for (int i = (n/2)-1; i >= 0; i--){
            heapify(a,n,i);
        }
        for (int i = n-1; i > 0; i--){
            int temp = a[0];
            a[0]=a[i];
            a[i]=temp;
            heapify(a,i,0);
        }
    }
    private static void heapify(int[] a,int n,int i){
        int largest = i;
        int left =  i * 2 +1;
        int right = i * 2  + 2 ;
        if (left < n &&  a[left] > a[largest]) largest = left;
        if (right < n &&  a[right] > a[largest]) largest = right;

        if (largest != i){
            int temp = a[i];
            a[i] = a[largest];
            a[largest] = temp;
            heapify(a,n,largest);
        }
    }
}
