package Sorting;

import java.util.Arrays;

public class InsertionSortt {
    public static void main(String[] args) {
        int[] arr = {8,0,4,8,2,7,1,2,3,4,5};
        insertion(arr);
        System.out.println(Arrays.toString(arr));
    }
    private static void insertion(int[] a){

        for (int i = 1; i < a.length; i++) {
            int value = a[i];
            int j = i - 1;
            while (j >= 0 && a[j] > value){
                a[j+1] = a[j];
                j--;
            }
            a[j+1] = value;
        }
    }
}

