package stacks;

import java.util.Stack;

public class StringCkecker {
    public static void main(String[] args) {
        if (isValidSyntax("{}()[[]]((()){}")){
            System.out.println("Valid");
        }else{
            System.out.println("Not valid");
        }
    }

    public static boolean isValidSyntax(String s) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '{' || ch == '(' || ch == '<' || ch == '[') {
                stack.push(ch);
            }else{
                char top = stack.pop();
                if ((top == '{' && ch != '}') || (top == '(' && ch != ')') || (top == '<' && ch != '>') || (top == '[' && ch != ']')){
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }
}