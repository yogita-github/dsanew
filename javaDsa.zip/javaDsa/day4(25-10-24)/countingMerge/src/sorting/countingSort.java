package sorting;

import java.util.Arrays;

public class countingSort {
    public static void main(String[] args) {
        int[] a={1,4,3,0,5,9,8,10,7,1,3,3,2,2};
        System.out.println(Arrays.toString(a));

        int max = Integer.MIN_VALUE;
        for (int i : a) max = Math.max(i,max);
        int[] count = new int[max+1];

        for (int i = 0; i < a.length; i++){
            count[a[i]]++;
        }

        int[] ans = new int[a.length];
        int index = 0;

        for (int i = 0; i < count.length ; i++) {
            int ct = count[i];
            while (ct>0){
                ans[index++]=i;
                ct--;
            }
        }
        System.out.println(Arrays.toString(ans));
    }
}
