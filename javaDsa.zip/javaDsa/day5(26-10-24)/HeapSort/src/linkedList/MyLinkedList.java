package linkedList;

public class MyLinkedList {

    class Node{
        int value;
        Node next;

        public Node(int v){
            this.value = v;
            this.next=null;
        }
    }
    Node head;

    //add
    public void add(int v){
        Node node = head;
        Node newNode = new Node(v);
        if (head == null){
            head = newNode;
        }else{
            while (node.next != null){
                node=node.next;
            }
            node.next=newNode;
        }
    }

    //display
    public void display(){
        Node node = head;
        while (node != null){
            System.out.print(node.value + " -->  ");
            node=node.next;
        }
    }

    public void addAtIndex(int v,int index){
        Node newNode = new Node(v);
        Node node = head;
        Node prev = null;

        if (head == null){
            head = newNode;
            System.out.println("No value found in Linked List.. so added first ");
        }
        else if(index == 1) {
          Node actual = head;
          newNode.next=actual;
          head = newNode;
        }
        else{
            while (node.next != null && index != 1) {
                prev = node;
                node = node.next;
                index--;
            }
            if (node.next != null){
                prev.next = newNode;
                newNode.next = node;
            }else{
                node.next=newNode;
            }
        }
    }

    public void deleteByValue(int val){
        Node node = head;
        Node prev = null;
        if (head == null){
            System.out.println("List is empty");
            return;
        }
        if (head.value == val){
            if (head.next == null){
                head = null;
            }else{
                head=head.next;
            }
        }else{
            while (node.value != val && node != null ){
                prev=node;
                node=node.next;
            }
            prev.next=node.next;
            node.next=null;
        }
    }

    public void deleteAllByValue(int val){
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        while (head != null && head.value == val) {
                head = head.next;
        }
        Node node = head;
        Node prev = null;
        while (node != null) {
            if (node.value == val){
                prev.next=node.next;
            }else{
                prev=node;
            }
            node=node.next;
        }
    }
    public void insertAfterValue(int val,int n){
        Node newNode = new Node(val);
        Node prev = null;
        Node current = head;
        if (head == null) {
            System.out.println("List is empty");
            head=newNode;
            return;
        }
        if (head.value == n){
            Node actual = head.next;
            head.next=newNode;
            newNode.next=actual;
            return;
        }else{
            while (current != null){
                prev=current;
                current=current.next;
                if(current != null && current.value == n){
                    if (current.next == null){
                        current.next = newNode;
                        return;
                    }else {
                        Node actual = current.next;
                        current.next = newNode;
                        newNode.next = actual;
                        return;
                    }
                }
            }
        }
        prev.next=newNode;
        System.out.println("value not present so added last..");
    }

    public int getCountOf(int val){
        int count = 0;
        Node current = head;
        while (current != null){
            if (current.value == val) count++;
            current=current.next;
        }
        return count;
    }

    public void reverseLinkedList(){
        Node current = head;
        Node prev = null;
        Node future = null;
        while (current != null) {
            future = current.next;
            current.next = prev;
            prev = current;
            current = future;
        }
        head = prev;
    }

    //reverse from mid
    public void reverseHalf(){
        Node fast = head;
        Node slow = head;
        while (fast != null){
            fast=fast.next.next;
            slow=slow.next;
        }
        Node mid = slow;
        slow=slow.next;
        Node past = null;
        while (slow != null){
            Node future = slow.next;
            if (past==null){
                slow.next=null;
            }else{
                slow.next=past;
            }
            past=slow;
            slow = future;
        }
        mid.next=past;
    }
}
