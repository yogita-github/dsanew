public class CircularLinkedList {
        class Node{
            int val;
            Node next;
            public Node(int val){
                this.val = val;
                this.next=null;
            }
        }
        Node head = null;
        Node tail = null;

        public void addNode(int val){
            Node newNode = new Node(val);
            if(head==null){
                head=newNode;
                head.next=head;
            }
            else if(head != null && head.next == null){
                Node temp = head;
                temp.next = newNode;
                newNode.next=head;
            }else{
                Node last = tail;
                last.next=newNode;
                newNode.next=head;
            }
            tail=newNode;
        }

        public void print(){
            if (head==null){
                System.out.println("List is empty");
            }else{
                Node node = head;
                while (node != tail){
                    System.out.println(" --> " + node.val);
                    node=node.next;
                }
                System.out.println(" --> "  + node.val);
                System.out.println("----------");
            }
        }

        public void insert(int val,int index){
            Node newNode = new Node(val);
            if (head == null){
                System.out.println("No list found");
            }
            else if (index == 0 ){
                newNode.next=head;
                head = newNode;
            }else{
                Node temp = head;
                while (temp != tail && index != 1){
                    temp=temp.next;
                    index--;
                }
                if(temp == tail && index != 1){
                    if (index != 1) System.out.println("index uut of bound..");
                }else if(temp == tail && index == 1){
                    Node last = tail;
                    last.next=newNode;
                    newNode.next=head;
                    tail=newNode;
                }else{
                    Node n1 = temp.next;
                    newNode.next=n1;
                    temp.next=newNode;
                }
            }
        }

        public void addBefore(int val,int key){
            Node newNode = new Node(val);
            if (head == null) System.out.println("List not found");
            if (head.val == key){
                newNode.next=head;
                head=newNode;
                tail.next=head;
            }else{
                Node temp = head;
                Node pre = null;
                while (temp != tail && temp.val != key){
                    pre = temp;
                    temp=temp.next;
                }
                if (temp == tail && temp.val != key){
                    System.out.println("Key not found");
                }else{
                    pre.next= newNode;
                    newNode.next = temp;
                }
            }
        }

        public void addAfter(int val,int key){
            Node newNode = new Node(val);
            if(head == null){
                System.out.println("List not found..");
            }else{
                Node temp = head;
                while (temp != tail && temp.val != key){
                    temp=temp.next;
                }
                if (temp == tail && temp.val != key){
                    System.out.println("Key not found");
                }else if (temp == tail && temp.val == key) {
                    temp.next=newNode;
                    tail = newNode;
                    newNode.next=head;
                }else{
                    newNode.next = temp.next;
                    temp.next=newNode;
                }
            }
        }

        public boolean deleteByPosition(int position){
            if (head == null){
                System.out.println("List is empty");
                return false;
            }
            if (position == 1) {
                if (head.next == head) {
                    head = null;
                    tail = null;
                    return true;
                }else {
                    Node temp = head;
                    head=head.next;
                    tail.next=head;
                    temp.next=null;
                }
                return true;
            }else{
                Node temp = head;
                while (temp != tail && position!= 2 ){
                    temp=temp.next;
                    position--;
                }
                if (temp == tail && position != 2){
                    System.out.println("Index out of bound");
                    return false;
                }else if(temp.next == tail && position == 2){
                    tail=temp;
                    temp.next=head;
                    tail.next=head;
                    return true;
                }else{
                    Node del = temp.next;
                    temp.next = del.next;
                    del.next=null;
                    return true;
                }
            }
        }


        public int size(){
            int count = 1;
            if (head == null){
                return 0;
            }else{
                Node temp = head;
                while (temp != tail) {
                    temp=temp.next;
                    count++;
                }
            }
            System.out.println("Size is : " + count);
            return count;
        }

        public int deleteAllByValue(int val){
            int count = 0;
            if (head == null) return count;
            else if(head.val == val && head.next == head){
                head=null;
                tail=null;
                return 1;
            }
            else{
                while (head != tail && head.val == val){
                    head = head.next;
                    count++;
                }
                Node current = head;
                Node pre = null;
                while (current != tail){
                    if (current.val == val){
                        pre.next=current.next;
                        count++;
                    }else {
                        pre = current;
                    }
                    if (current.next == tail && current.next.val == val){
                        pre.next=head;
                        tail=pre;
                        count++;
                    }
                    current=current.next;
                }
            }
            return count;
        }

        public void reverse(){
            if (head == null)return;
            Node current = head;
            Node past = null;
            Node first=head;
            while (current != tail){
                Node future = current.next;
                current.next=past;
                past=current;
                current=future;
            }
            Node newStart = tail;
            newStart.next=past;
            head=newStart;
            tail=first;
        }

        public void sortLinkedList(){
            if (head == null) return;
            int n = size();
            int index = 0;
            while (n != 1){
                int i = index;
                Node current = head;
                while (i != 0){
                    current=current.next;
                    i--;
                }
                Node large = current;
                Node small =current.next;
                while (current != tail){
                    current = current.next;
                    if ((current != tail && small != tail )&& current.val < small.val){
                        small=current;
                    }
                }
                if (small != tail && large != tail && (small.val < large.val)){
                    int temp = small.val;
                    small.val=large.val;
                    large.val=temp;
                }
                index++;
                n--;
            }
        }

        public void keepEven(){
            if (head == null ) return;
            Node current = head;
            Node newHead = null;
            int index = 1;
            Node copy = null;

            while (current != tail){
                if (index % 2 == 0) {
                    Node newNode = new Node(current.val);
                    if (newHead == null) {
                        newHead = newNode;
                        copy = newHead;
                    }else{
                        copy.next = newNode;
                        copy=copy.next;
                    }
                }
                index++;
                current=current.next;
            }
            tail=copy;
            head = newHead;
        }

        public void keepOdd() {
            if (head == null) return;
            Node newHead = null;
            Node current = head;
            Node copy = null;
            int index = 1;
            while (current != tail) {
                if (index % 2 != 0) {
                    Node newNode = new Node(current.val);
                    if (newHead == null){
                        newHead = newNode;
                        copy=newHead;
                    }
                    else {
                        copy.next=newNode;
                        copy=copy.next;
                    }
                }
                index++;
                current=current.next;
            }
            if (current == tail && index  % 2 == 1){
                Node newNode = new Node(current.val);
                copy.next=newNode;
                copy=newNode;
            }
            tail=copy;
            head = newHead;
        }

        public void updateValue(int key,int newVal){
            if (head == null){
                System.out.println("List is empty");
                return;
            }
            Node current = head;
            while (current != tail){
                if (current.val == key){
                    current.val=newVal;
                }
                current=current.next;
            }
            if (current.val==key) current.val=newVal;
        }

    public void keepOnly(int val){
        if (head == null){
            System.out.println("List is empty..");
        }
        else{
            while (head != tail && head.val != val){
                head=head.next;
            }
            Node temp = head;
            Node pre = null;

            while (temp != tail){
                if (temp.val != val) {
                    pre.next = temp.next;
                } else{
                    pre=temp;
                }
                if (temp.next == tail && temp.next.val != val){
                    pre.next=head;
                    tail=pre;
                }
                temp=temp.next;
            }
            if (pre == null){
                tail=null;
                head=null;
            }else{
                tail = temp;
            }
        }
    }

    public void reverseHalf(){
        Node fast = head;
        Node slow = head;
        while (fast != tail && fast.next != tail){
            fast=fast.next.next;
            slow=slow.next;
        }
        Node mid = slow;
        slow=slow.next;
        Node past = null;
        while (slow != head){
            Node future = slow.next;
            if (past==null){
                slow.next=null;
            }else{
                slow.next=past;
            }
            past=slow;
            slow = future;
        }
        Node current = past;
        while (current.next != null){
            current=current.next;
        }
        tail=current;
        mid.next=past;
    }

    public int findOccuranceOf(int v){
            int count = 0;
            if (head == null){
                System.out.println("List is empty..");
                return 0;
            }else {
                Node current = head;
                while (current != tail) {
                    if (current.val == v) count++;
                    current=current.next;
                }
                if (tail.val == v) count++;
            }
             return count;
    }

    public void multiplyNodesExceptSelf(){
            if (head==null) System.out.println("List is empty");
            else {
                Node newHead = null;
                Node copy = null;
                Node current = head;
                while(current!=tail){
                    Node temp = head;
                    int mul=1;
                    while(temp!=tail){
                        if(temp==current) continue;
                        mul= mul*temp.val;
                    }
                    if(copy==null){
                        copy =new Node(mul);
                        newHead=copy;
                        copy=copy.next;
                    }else {

                    }
                }
            }
    }

}
