package hashList2;

import java.sql.SQLOutput;
import java.util.Scanner;

public class HashTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = 5;
        HashLinkedList[] hlst = new HashLinkedList[num];
        for (int i = 0; i < hlst.length; i++) {
            hlst[i] = new HashLinkedList();
        }
        int choice;
        do {
            choice = 0;
            System.out.println("1.Add \n2. Search \n3.Delete \n4.Display \n5.Exit");
            System.out.println("Enter your choice");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter a number");
                    int val = sc.nextInt();
                    addHashTable(hlst, val);
                    break;
                case 2:
                    System.out.println("Enter a number");
                    val = sc.nextInt();
                    boolean res = searchHashTable(hlst, val);
                    if (res) {
                        System.out.println("Element found");
                    } else {
                        System.out.println("Element not found");
                    }
                    break;
                case 3:
                    System.out.println("Enter a number");
                    val = sc.nextInt();
                    deleteHashTable(hlst, val);
                    break;
                case 4:
                    displayhashTable(hlst);
                    break;
                case 5:
                    System.out.println("Thanks for visiting");
                    sc.close();
                    break;
                default:
                    System.out.println("Invalid choice selected");
                    break;
            }

        } while (choice != 5);

    }
    private static void addHashTable(HashLinkedList[] hashtable, int data) {
        int bucket=data%hashtable.length;
        hashtable[bucket].add(data);

    }
    private static boolean deleteHashTable(HashLinkedList[] hashtable, int data) {
        int bucket=data%hashtable.length;
        return hashtable[bucket].delete(data);

    }

    private static boolean searchHashTable(HashLinkedList[] hashtable, int data) {
        int bucket=data%hashtable.length;
        return hashtable[bucket].searchValue(data);
    }
    private static void displayhashTable(HashLinkedList[] hashtable) {
        for(int i=0;i<hashtable.length;i++) {
            System.out.print(i+"--->");
            hashtable[i].displayList();
            System.out.println();
        }
        System.out.println("--------------------------------------");
    }

}
