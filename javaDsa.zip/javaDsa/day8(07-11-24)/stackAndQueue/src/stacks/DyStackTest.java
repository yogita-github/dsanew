package stacks;

public class DyStackTest {
    public static void main(String[] args) {
        DynamicStack stack = new DynamicStack();
        for (int i =1; i < 10; i++){
            stack.push(i);
        }
        for (int i =1; i < 8; i++){
            stack.pop();
        }
        for (int i =1; i < 10; i++){
            stack.push(i);
        }
        for (int i =1; i < 8; i++){
            stack.pop();
        }
        for (int i =1; i < 10; i++){
            stack.push(i);
        }
        for (int i =1; i < 8; i++){
            stack.pop();
        }
        for (int i =1; i < 10; i++){
            stack.push(i);
        }
        for (int i =1; i < 8; i++){
            stack.pop();
        }
        int n = 100;
    }
}
