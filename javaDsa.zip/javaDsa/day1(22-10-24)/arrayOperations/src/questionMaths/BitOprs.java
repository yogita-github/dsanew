package questionMaths;

public class BitOprs {
    public static void main(String[] args) {
        int[] arr = {2, 3, 3, 4, 2, 6, 4};
        System.out.println(ans(arr));
    }

    private static int ans(int[] arr) {
        int unique = 0;

        for(int n : arr) {
            unique ^= n;
        }

        return unique;
    }
    private static int convert(int n ){
        int count = 0;
        while (n > 0){
            count++;
            n = n & (n-1);
        }
        return count;
    }

}
