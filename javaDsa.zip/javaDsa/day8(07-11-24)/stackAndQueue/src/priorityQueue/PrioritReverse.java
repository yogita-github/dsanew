package priorityQueue;

public class PrioritReverse {
}
