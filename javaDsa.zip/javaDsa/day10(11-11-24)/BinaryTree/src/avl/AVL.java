package avl;

import java.util.*;

public class AVL {
    class TreeNode {
        int val;
        int height;
        TreeNode left;
        TreeNode right;

        public TreeNode(int i) {
            this.val = i;
            this.left = null;
            this.right = null;
            this.height = 1;
        }
    }

    private TreeNode root;

    public AVL() {
        root = null;
    }

    public int height() {
        return height(root);
    }

    private int height(TreeNode node) {
        if (node == null) return 0;
        return node.height;
    }

    public void insert(int i) {
        root = insert(root, i);
    }

    private TreeNode insert(TreeNode root, int i) {
        if (root == null) {
            return new TreeNode(i);
        }

        if (i < root.val) {
            root.left = insert(root.left, i);
        }else{
            root.right = insert(root.right, i);
        }

        /*else {
        else  if (i > root.val) {


        }
            return root; // Duplicates are not allowed
        }*/


        root.height = Math.max(height(root.left), height(root.right)) + 1;
        return rotate(root);
    }

    public void showTree() {
        showTree(root, "Root");
    }

    private void showTree(TreeNode node, String prefix) {
        if (node == null) return;

        System.out.println(prefix + ": " + node.val);

        showTree(node.left, "Left of " + node.val);
        showTree(node.right, "Right of " + node.val);
    }

    public boolean isBalanced() {
        return isBalanced(root);
    }

    private boolean isBalanced(TreeNode node) {
        if (node == null) return true;

        return Math.abs(height(node.left) - height(node.right)) <= 1 &&
                isBalanced(node.left) && isBalanced(node.right);
    }

    public TreeNode rotate(TreeNode node) {
        int balance = height(node.left) - height(node.right);

        // Left heavy
        if (balance > 1) {
            if (height(node.left.left) >= height(node.left.right)) {
                return rightRotate(node); // Left-Left case
            }

            node.left = leftRotate(node.left); // Left-Right case
            return rightRotate(node);
        }

        // Right heavy
        if (balance < -1) {
            if (height(node.right.right) >= height(node.right.left)) {
                return leftRotate(node); // Right-Right case
            }
            node.right = rightRotate(node.right); // Right-Left case
            return leftRotate(node);
        }

        return node; // No rotation needed
    }

    public TreeNode rightRotate(TreeNode node) {
        TreeNode child = node.left;
        TreeNode gc = child.right;

        child.right = node;
        node.left = gc;

        node.height = Math.max(height(node.left), height(node.right)) + 1;
        child.height = Math.max(height(child.left), height(child.right)) + 1;

        return child;
    }

    public TreeNode leftRotate(TreeNode node) {
        TreeNode child = node.right;
        TreeNode gc = child.left;

        child.left = node;
        node.right = gc;

        node.height = Math.max(height(node.left), height(node.right)) + 1;
        child.height = Math.max(height(child.left), height(child.right)) + 1;
        return child;
    }

    public List<Integer> inOrder(){
        List<Integer> ans = new ArrayList<>();
        inorder(root,ans);
        return ans;
    }
    private List<Integer> inorder(TreeNode current,List<Integer> ans){
        if(current==null){
            return ans;
        }
        inorder(current.left,ans);
        ans.add(current.val);
        inorder(current.right,ans);
        return ans;
    }

    public List<Integer> preOrder(){
        List<Integer> ans = new ArrayList<>();
        preOrder(root,ans);
        return ans;
    }
    public List<Integer> preOrder(TreeNode current,List<Integer> ans){
        if(current==null){
            return ans;
        }
        ans.add(current.val);
        inorder(current.left,ans);
        inorder(current.right,ans);
        return ans;
    }


    public List<Integer> postOrder(){
        List<Integer> ans = new ArrayList<>();
        postOrder(root,ans);
        return ans;
    }
    public List<Integer> postOrder(TreeNode current,List<Integer> ans){
        if(current==null){
            return ans;
        }
        postOrder(current.left,ans);
        postOrder(current.right,ans);
        ans.add(current.val);
        return ans;
    }

}