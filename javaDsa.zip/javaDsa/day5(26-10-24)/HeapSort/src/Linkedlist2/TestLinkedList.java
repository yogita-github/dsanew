package Linkedlist2;

public class TestLinkedList {
    public static void main(String[] args) {
        SinglyLinkedList lst = new SinglyLinkedList();
        lst.addNode(5);
        lst.addNode(7);
        lst.displayData();
        System.out.println("----------------------------->");
        lst.addByPosition(45,1);
        lst.displayData();
        System.out.println("----------------------------->");
        lst.deleteByValue(7);
        lst.displayData();
        System.out.println("----------------------------->");
        lst.addByPosition(30,2);
        lst.displayData();
    }
}
