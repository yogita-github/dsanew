package sorting;

import java.util.Arrays;

public class BubbleSort {
    public static void main(String[] args) {
        int[] array = {70,40,50,90,100,10,30,20,10,30};
        bubble(array);
        System.out.println(Arrays.toString(array));
    }
    public static void bubble(int[] array){
        int n=array.length;
        for(int i=0;i<n;i++){
            int swap=0;
            for(int j=1;j<n-i;j++){
                if(array[j-1]>array[j]){
                    System.out.println("swapped between  : " + array[j-1] + "  ----> "+ array[j]);
                    int temp = array[j];
                    array[j] = array[j-1];
                    array[j-1]=temp;
                    swap++;
                }
            } if(swap==0) break;
        }

    }
}
