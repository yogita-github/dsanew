package priorityQueue;

public class TestPriorityMin {
    public static void main(String[] args) {
        PriorityNaturalOrder pq = new PriorityNaturalOrder(10);
        pq.add(10);
        pq.add(20);
        pq.add(50);
        pq.add(30);
        pq.add(40);
        pq.add(00);
        pq.add(1);

        for (int i =0; i < 10; i++){
            System.out.println(pq.poll());
        }
//        while (!pq.isEmpty()){
////            System.out.println(pq.poll());
//        }
    }
}
