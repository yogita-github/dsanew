package Sorting;

import java.util.Arrays;

public class MergeSort {
    public static void main(String[] args) {
        int[] arr1={23,43,1,3,5,7,8,46,75,90};
        int[] arr2={45,4,7,8,35,90,45};
        int[] arr3=new int[arr1.length+ arr2.length];
        merge(arr1,arr2,arr3);
        System.out.println(Arrays.toString(arr3));
        mergeSort(arr3);
    }

    private static void mergeSort(int[] arr3) {
        int n= arr3.length;
        for(int i=0;i< n;i++){
            int j=i-1;
            int num = arr3[i];
            while(j>=0 && arr3[j]>num){
                arr3[j+1] = arr3[j];
                j--;
            }
            arr3[j+1]=num;
        }
        System.out.println(Arrays.toString(arr3));
    }

    private static void merge(int[] arr1, int[] arr2, int[] arr3) {
    int i=0,j=0,k=0;
        while(i<arr1.length && j<arr2.length){
            if(arr2[j]<arr1[i]){
                arr3[k]=arr1[i];
                i++;
                k++;
            }else{
                arr3[k]=arr2[j];
                j++;
                k++;
            }
            while(i<arr1.length){
                arr3[k]=arr1[i];
                i++;
                k++;
            }
            while(j<arr2.length){
                arr3[k]=arr2[j];
                j++;
                k++;
            }
            System.out.println(Arrays.toString(arr3));
        }
    }


}
