package sorting.me;

import java.util.Arrays;

public class Selection {
    public static void main(String[] args) {
        int[] array = {70,40,50,30,30,30,30,30,30,30,3,90,100,10,30,20,10,30,50,20,10};
        System.out.println(Arrays.toString(array));
        selection(array);
        System.out.println(Arrays.toString(array));
    }

    private static void selection(int[] a){
        for (int i = 0; i < a.length; i++) {
            int minIndex = i;
            int swap = 0;
            for (int j = i + 1; j < a.length; j++){
                if (a[minIndex] > a[j]){
                    minIndex=j;
                    swap++;
                }
            }
            if (swap != 0) {
                int temp = a[i];
                a[i] = a[minIndex];
                a[minIndex] = temp;
            }else break;
        }
    }

}
