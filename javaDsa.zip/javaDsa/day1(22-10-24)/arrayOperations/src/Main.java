import arrayOperations.ArrayService;
import arrayOperations.ArrayServiceImpl;
import reccursion.ReccursionService;
import reccursion.ReccursionServiceImpl;
import search.SearchService;
import search.SearchServiceImpl;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        ArrayService arrayService = new ArrayServiceImpl();
        ReccursionService reccursionService = new ReccursionServiceImpl();
        SearchService search = new SearchServiceImpl();


        int[] array = {70,40,50,90,100,10,30,20,10,30,100,50,20,10,70,40,50,90,100};
        int[] array2 = {1,2,6,8,5,6,10,4,9,16,14,13,12};
        Arrays.sort(array2);
        int[] array22 = {1,2,6,9,145,145};
        //searching
        System.out.println(search.binarySearch(array2,0,array2.length,10));
//        System.out.println(Arrays.toString(a));

        int[] merge = arrayService.merger(new int[] {3,5,9,15},new int[] {1,6,10});
        System.out.println(Arrays.toString(merge));

    }

}