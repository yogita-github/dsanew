public class Main {
    public static void main(String[] args) {
        int sum = 52;
        int product = 51;
        int n1 = sum/2;
        int n2=sum-n1;
        int[] ans = nums(sum,product,n1,n2);
        System.out.println("nums are : " + ans[0] + " & " + ans[1]);

        int[] a = {1,2,3,4,6,7,8,9,10};
        System.out.println(missingNumber(a));
    }
    private static int[] nums(int s,int p,int n1,int n2){
        if (n1==0 || n2 == 0) return new int[]{-1,-1};
        while (n1 != 0 && n2 != 0){
            if (n1*n2 == p && n1+n2 == s){
                return new int[] {n1,n2};
            }
            if (n1*n2 > p){
                return nums(s,p,n1,n2-1);
            }if(n1*n2<p){
                return nums(s,p,n1+1,n2);
            }
        }
        return new int[]{-1,-1};
    }

    private static int missingNumber(int[] a){
        int n = a.length;
        int missing = n;
        for (int i = 0; i < a.length; i++) {
            missing ^= a[i];
        }
        for (int i = 0; i < a.length; i++) {
            missing ^= a[i];
        }
        return missing;
    }

    private static int twice(int[] a,int range){
        int n = a.length;
        int tracker[] = new int[range+1];
        for (int i = 0; i < n; i++) {
            tracker[a[i]]++;
            if (tracker[a[i]] == 3){
                return a[i];
            }
        }
        return -1;
    }
}