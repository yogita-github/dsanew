package reccursion;

public class ReccursionServiceImpl implements ReccursionService{


    public int factorial(int a) {
        if(a==1) return 1;
        return a*factorial(a-1);

    }


    public int sumTillNthNumber(int a) {
        if(a==1) return 1;
        return a+sumTillNthNumber(a-1);
    }
}
