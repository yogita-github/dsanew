import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        DLinkedList list = new DLinkedList();

        list.addNode(2);
        list.addNode(3);
        list.addNode(4);
        list.addNode(8);
        list.addNode(5);
        list.addNode(6);
        list.addNode(1);
        list.addNode(7);
        list.print();
        list.sortLinkedList();
        list.print();
        list.keepEven();
        list.sortLinkedList();
        list.print();
    }

}