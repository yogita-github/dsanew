package graphClass;

import java.util.*;

public class Graph {

    class Node{
        int weight;
        int dest;
        public Node(int d,int w){
            this.dest=d;
            this.weight=w;
        }
    }

    private List<List<Node>> adj;

    public void buildGraph(int[][] grid){
        int v = grid.length;
        adj=new ArrayList<>();

        for (int i=0; i < v; i++){
            adj.add(new ArrayList<>());
        }

        for (int i=0;i<v;i++){
            for (int j=0; j < v; j++){
                if (grid[i][j] != 0){
                    adj.get(i).add(new Node(j,grid[i][j]));
                }
            }
        }
    }

    public void showGraph(){
        for (int i =0; i < adj.size(); i++){
            StringBuilder str = new StringBuilder();

            for (Node node : adj.get(i)){
                str.append("  --" + node.weight + "-->" + node.dest);
            }
            System.out.println(i + str.toString());
        }
    }

    public List<Integer> dfs(){
        List<Integer> ans = new ArrayList<>();
        boolean[] visited = new boolean[adj.size()];
        Stack<Integer> stack=new Stack<>();

        stack.push(0);
        visited[0] = true;
        while (!stack.isEmpty()){
            int current = stack.pop();
            ans.add(current);
            for (Node n : adj.get(current)){
                int node = n.dest;
                if ( !visited[node] ){
                    visited[node] = true;
                    stack.push(node);
                }
            }
        }
        return ans;
    }

    public List<Integer> bfs(){
        List<Integer> ans = new ArrayList<>();
        boolean[] visited = new boolean[adj.size()];
        Queue<Integer> queue = new LinkedList<>();

        queue.offer(0);
        visited[0] = true;

        while (!queue.isEmpty()){
            int current = queue.poll();
            ans.add(current);
            for (Node n : adj.get(current)){
                int node = n.dest;
                if ( !visited[node] ){
                    visited[node] = true;
                    queue.offer(node);
                }
            }
        }
        return ans;
    }

    public int[] dijk(){
        int[] dist = new int[adj.size()];
        Arrays.fill(dist,Integer.MAX_VALUE);
        Queue<Node> queue = new LinkedList<>();
        queue.offer(adj.get(1).get(0));
        dist[0]=0;

        while (!queue.isEmpty()){
            Node current = queue.poll();
            int node = current.dest;
            int weight = current.weight;

            for (Node adjNode : adj.get(node)){
                int dest = adjNode.dest;
                int wt = adjNode.weight;
                int newDist = dist[node] + wt;

                if (newDist < dist[dest]){
                    dist[dest] = newDist;
                    queue.offer(adjNode);
                }
            }
        }
        return dist;
    }

    public int[] topoSort(){
        int[] ans = new int[adj.size()];
        int[] inDegree = new int[adj.size()];
        for (List<Node> list : adj){
            for (Node n : list){
                int node = n.dest;
                inDegree[node]++;
            }
        }

        Queue<Integer> queue = new LinkedList<>();
        ArrayList<Integer> ansList = new ArrayList<>();
        for (int i =0; i < inDegree.length; i++){
            if (inDegree[i] == 0){
                ansList.add(i);
                queue.add(i);
            }
        }

        while (!queue.isEmpty()){
            int node = queue.poll();

            for (Node n : adj.get(node)){
                int src = n.dest;
                inDegree[src]--;
                if (inDegree[src] == 0){
                    queue.add(src);
                    ansList.add(src);
                }
            }
        }
        int index = 0;
        for (int i : ansList){
            ans[index++] = i;
        }
        return ans;
    }

    public int findKey(int[] k, boolean[] v){
        int minIndex = -1;
        int minValue = Integer.MAX_VALUE;
        for (int i =0; i < k.length; i++){
            if (k[i] < minValue && !v[i]){
                minValue = k[i];
                minIndex = i;
            }
        }
        return minIndex;
    }


    public void prims(int[][] grid){
        int n = grid.length;
        int[] parent = new int[n];
        int key[] = new int[n];
        boolean[] visited = new boolean[n];

        for (int i = 0; i< n; i++){
            parent[i] = Integer.MAX_VALUE;
            visited[i] = false;
        }
        key[0] = 0;
        parent[0] = -1;
        for (int i =0; i < n; i++){
            int u = findKey(key,visited);
            visited[u] = false;

            for (int v = 0; v < n; v++) {
                if (grid[u][v] != 0 && !visited[v] && grid[u][v] < key[v]) {
                    parent[v] = u;
                    key[v] = grid[u][v];
                }
            }
        }
        printPrims(parent,grid);
    }

    public void printPrims(int[] p, int[][] k){
        for(int i=1;i<p.length; i++){
            System.out.println(p[i] + " --> "  + i + " "+ k[i][p[i]]);
        }
    }
}
