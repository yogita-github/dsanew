package search;

public class SearchServiceImpl implements SearchService{

    public int linearSearch(int[] a,int target) {
        for (int i = 0; i < a.length; i++) {
            if(a[i]==target)return i;
        }
        return -1;
    }

    public int binarySearch(int[] a,int low,int high,int target) {
        if(low > high) return -1;
        if(low<=high) {
            int mid = (low + high) / 2;

            if (a[mid] == target) {
                return mid;
            }

            else if(target<a[mid]){
                high=mid-1;
                return binarySearch(a,low,high,target);
            }
            else{
                low=mid+1;
                return binarySearch(a,low,high,target);
            }
        }
        return -1;
    }

}
