package sorting;

import java.util.Arrays;

public class SelectionSort {
    public static void main(String[] args) {
        int[] a={1,4,3,0,5,9,8,10,7,1,3,3,2,2};
        System.out.println(Arrays.toString(a));
        for (int i = 0; i < a.length; i++) {
            int minIndex = i;
            for (int j = i + 1; j < a.length ; j++) {
                if (a[minIndex] > a[j]){
                    minIndex = j;
                }
            }
            int temp = a[minIndex];
            a[minIndex] =a[i];
            a[i]=temp;
        }

        System.out.println(Arrays.toString(a));
    }
}
