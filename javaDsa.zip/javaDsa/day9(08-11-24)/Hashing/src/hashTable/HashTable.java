package hashTable;

public class HashTable {
    LinkedList[] hashArray = new LinkedList[5];

    public HashTable(){
        for (int i =0; i < hashArray.length;i++){
            hashArray[i] = new LinkedList();
        }
    }

    public void put(int i,String v){
        int pos = i % hashArray.length;
        hashArray[pos].add(i,v);
    }
    public void removeByKey(int i){
        int pos = i % hashArray.length;
        hashArray[pos].remove(i);
    }

    public boolean containsKey(int i){
        int pos = i % hashArray.length;
        String ans = hashArray[pos].findByKey(i);
        if (ans == null || ans.length() == 0){
            return false;
        }
        return true;
    }


    public String getVal(int i){
        int pos = i % hashArray.length;
        String ans = hashArray[pos].findByKey(i);
        if (ans == null || ans.length() == 0){
            System.out.println("Key not found");
            return null;
        }
        return ans;
    }

    public int size(){
        int count = 0;
        for (int i =0; i < hashArray.length;i++){
            count += hashArray[i].getSize();
        }
        return count;
    }

    public boolean isEmpty(){
        return size()==0;
    }

    public void clear(){
        for (int i =0; i < hashArray.length;i++){
            hashArray[i].clearList();
        }
    }

    public void putAll(HashTable t){
        int[] key = t.getKeys();
        String[] value = t.getValues();

        for (int i =0; i < key.length; i++){
            this.put(key[i],value[i]);
        }
    }

    public int[] getKeys(){
        int[] ans = new int[size()];
        int count = 0;
        for (int i=0; i < hashArray.length ; i++){
            int[] current = hashArray[i].giveKeys();
            if (current.length != 0){
                for (int j =0; j < current.length; j++){
                    ans[count++] = current[j];
                }
            }
        }
        return ans;
    }

    public String[] getValues(){
        String[] ans = new String[size()];
        int count = 0;
        for (int i=0; i < hashArray.length ; i++){
            String[] current = hashArray[i].giveValues();
            if (current.length != 0){
                for (int j =0; j < current.length; j++){
                    ans[count++] = current[j];
                }
            }
        }
        return ans;
    }


    public String toString(){
        StringBuilder str = new StringBuilder();
        for (int i =0; i < hashArray.length; i++){
            String s = hashArray[i].getList();
            if (s != null){
                str.append("List numbre ").append(i+1).append(" --> ").append(s).append("\n");
            }
        }
        return str.toString();
    }

}
