public class Main {
    public static void main(String[] args) {
        int[] a = {70, 40, 50, 90, 100, 10, 30, 20, 10, 30, 100, 50, 20, 10, 70, 40, 50, 90, 100};


    }
}