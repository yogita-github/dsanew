package graphClass;

import java.util.List;

public class TestGraph {
    public static void main(String[] args) {
        Graph graph = new Graph();
        int[][] grid = {{0,0,0,1,1,0,0},{0,0,0,3,0,0,0},
                        {0,0,0,0,1,0,1},{0,0,0,0,1,1,1},
                        {0,0,0,0,0,0,1},{0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0}};
        graph.buildGraph(grid);
        graph.showGraph();
        List<Integer> ans = graph.dfs();

        System.out.println();
        for (int i : ans){
            System.out.print(i + " -- ");
        }
        System.out.println(" <-- dfs");

        System.out.println();
        int[] topo = graph.topoSort();
        for (int i : topo){
            System.out.print(i + " -> ");
        }
        System.out.println("Topo sort");

//        graph.prims(grid);
    }
}
