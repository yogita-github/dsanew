package arrayOperations;

public interface ArrayService {
    int findLargest(int[] a);
    int secondLargest(int[] a);
    int nThLargest(int[] a,int k);
    int primeSum(int[] a);
    int smallest(int[] a);
    int sumOfPerfectSquares(int[] a);
    int subarraySum(int[] a);
    int maxSubarraySum(int[] a);
    int minSubarraySum(int[] a);
    int findMissingFromNNUmbers(int[] a);
    int[] merger(int[] a ,int[] b);
    int[] rotate(int[] a);
    int[] findDoubles(int[] a);
    int[] twoSum(int[] a,int target);
    int[] threeSun(int[] a,int target);
    int[] productArray(int[] a);
    int missingPositive(int[] a);
    int findCountOf(int[] a,int target);
    int peakElement(int[] a);
    int valleyElement(int[] a);
    int[] subarrayWithGivenSum(int[] a,int target);
    boolean isSubset(int[] main,int[] sub);
    int[] unionAndIntersection(int[] a,int[] b);
    int countPairsWithSum(int[] a,int target);
    int[] commonCountInThreeArrays(int[] a,int[] b, int[] c);
    boolean subArrayWithZeroSum(int[] a);
    int[] findExtraNumbers(int[] a);
    int[] sortNRangedArray(int[] a);
}
