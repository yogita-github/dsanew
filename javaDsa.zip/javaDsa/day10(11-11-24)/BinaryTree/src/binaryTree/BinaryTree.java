package binaryTree;

import com.sun.source.tree.Tree;

import java.util.*;

public class BinaryTree {
    class TreeNode{
        int val;
        TreeNode left;
        TreeNode right;

        public TreeNode(int v){
            this.val=v;
            this.left=null;
            this.right=null;
        }
    }
        TreeNode root = null;


        public void addNode(int v){
            TreeNode newNode = new TreeNode(v);
            if (root == null){
                root=newNode;
            }else {
                TreeNode current = root;
                Boolean added = false;
                Queue<TreeNode> queue = new LinkedList<>();
                queue.add(root);
                while (!added){
                    current=queue.poll();
                    if (current != null){
                        if (current.left == null){
                            current.left=newNode;
                            added=true;
                        }else if (current.right == null){
                            current.right = newNode;
                            added=true;
                        }else{
                            queue.add(current.left);
                            queue.add(current.right);
                        }
                    }
                }
            }

        }


    public List preOrder(){
        List<Integer> ans = new ArrayList<>();
        if (root==null) return ans;
        Stack<TreeNode> stack = new Stack<>();
        stack.add(root);

        while (!stack.isEmpty()){
            TreeNode current = stack.pop();
            ans.add(current.val);
            if (current.right != null){
                stack.push(current.right);
            }
            if (current.left != null){
                stack.push(current.left);
            }
        }
        return ans;
    }

    public List inOrder(){
        List<Integer> ans = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        TreeNode current = root;
        boolean done = false;
        while (!done){
            if (current != null) {
                stack.add(current);
                current=current.left;
            }else{
                if (stack.isEmpty()){
                    done=true;
                }else{
                    current=stack.pop();
                    ans.add(current.val);
                    current=current.right;
                }
            }
        }
        return ans;
    }

    public List postOrder(){
        List<Integer> ans = new ArrayList<>();
        if (root==null) return ans;

        Stack<TreeNode> stack = new Stack<>();
        TreeNode prev = null;
        TreeNode current = root;

        while (current != null || !stack.isEmpty()){
            while (current != null){
                stack.push(current);
                current=current.left;
            }

            current=stack.peek();
            if (current.right == null || current.right == prev){
                ans.add(current.val);
                stack.pop();
                prev=current;
                current=null;
            }else {
                current=current.right;
            }
        }
        return ans;
    }

    public List bfs(){
        List<Integer> ans = new ArrayList<>();
        if (root == null) return ans;
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()){
            TreeNode current = queue.poll();
            ans.add(current.val);
            if (current.left != null){
                queue.add(current.left);
            }
            if (current.right != null){
                queue.add(current.right);
            }
        }
        return ans;
    }

}
