package hashTable;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        HashTable hashTable = new HashTable();
        HashTable hashTable1 = new HashTable();

        for (int i =0; i < 10; i++){
            hashTable.put(i,"Omen");
        }
        hashTable1.put(99,"Jhon");
        System.out.println(hashTable);
        hashTable1.putAll(hashTable);
        System.out.println(hashTable1);
        System.out.println(hashTable);
    }
}