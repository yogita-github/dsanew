public class DLinkedList {
    class Node{
        int val;
        Node next;
        Node prev;
        public Node(int val){
            this.val = val;
            this.next=null;
            this.prev=null;
        }
    }
    Node head = null;

    public void addNode(int val){
        Node newNode = new Node(val);
        if(head==null){
            head=newNode;
        }
        else if(head != null && head.next == null){
            Node temp = head;
            temp.next = newNode;
            newNode.prev=temp;
        }else{
            Node temp = head;
            while (temp.next != null){
                temp=temp.next;
            }
            temp.next=newNode;
            newNode.prev=temp;
        }
    }

    public void print(){
        if (head==null){
            System.out.println("List is empty");
        }else{
            Node node = head;
            while (node != null){
                System.out.println(" --> " + node.val);
                node=node.next;
            }
            System.out.println("----------");
        }
    }

    public void insert(int val,int index){
        Node newNode = new Node(val);
        if (head == null){
            System.out.println("No list found");
            head=newNode;
        }
        else if (index == 0 ){
                Node temp = head;
                newNode.next=temp;
                temp.prev=newNode;
                head = newNode;
        }else{
            Node temp = head;
            while (temp.next != null && index != 1){
                temp=temp.next;
                index--;
            }
            if(temp.next == null){
                if (index != 1) System.out.println("Out of bound, added to last index..");
                newNode.prev=temp;
                temp.next=newNode;
            }else{
                Node n1 = temp.next;
                n1.prev = newNode;
                newNode.next=n1;
                temp.next=newNode;
                newNode.prev=temp;
            }
        }
    }
    public void addBefore(int val,int key){
        Node newNode = new Node(val);
        if (head.val == key){
            newNode.next=head;
            head.prev=newNode;
            head=newNode;
        }else{
            Node temp = head;
            while (temp != null && temp.val != key){
                temp=temp.next;
            }
            if (temp == null || temp.val != key){
                System.out.println("Key not found");
            }else{
                Node p1 = temp.prev;
                p1.next=newNode;
                newNode.prev=p1;
                newNode.next = temp;
                temp.prev=newNode;
            }
        }
    }
    public void addAfter(int val,int key){
        Node newNode = new Node(val);
        if (head.val == key){
            if (head.next != null){
                Node n1 = head.next;
                n1.prev=newNode;
                newNode.next=n1;
            }
            newNode.prev=head;
            head.next=newNode;
        }else{
            Node temp = head;
            while (temp != null && temp.val != key){
                temp=temp.next;
            }
            if (temp == null || temp.val != key){
                System.out.println("Key not found");
            }else{
                if (temp.next != null) {
                    Node n1 = temp.next;
                    n1.prev = newNode;
                    newNode.next = n1;
                }
                newNode.prev = temp;
                temp.next=newNode;
            }
        }
    }
    public boolean deleteByIndex(int index){
        if (size() == index){
            System.out.println("Index out of bound");
            return false;
        }
        if (head == null){
            System.out.println("List is empty");
            return false;
        }
        if (index == 0){
            if (head.next == null){
                head = null;
            }else{
                Node temp = head;
                head = head.next;
                temp.next = null;
                temp=null;
            }
            return true;
        }else{
            Node temp = head;
            while (temp != null && index != 1){
                temp=temp.next;
                index--;
            }
            if (index + 1 > 1 && temp == null){
                System.out.println("Index out of bound..");
                return false;
            }else{
                if (temp.next != null && temp.next.next != null){
                    Node delete = temp.next;
                    Node n1 = temp.next.next;
                    n1.prev=temp;
                    temp.next=n1;
                    delete.next=null;
                    delete.prev = null;
                    delete=null;
                }else{
                    Node delete = temp.next;
                    temp.next=null;
                    delete=null;
                }
            }
        }
        return true;
    }
    public int size(){
        int count = 0;
        if (head == null){
            return 0;
        }else{
            Node temp = head;
            while (temp != null) {
                temp=temp.next;
                count++;
            }
        }
        return count;
    }

    public int deleteAllByValue(int val){
        int count = 0;
        if (head == null) return count;
        else{
            while (head != null && head.val == val){
                head = head.next;
                count++;
            }
            Node current = head;
            Node pre = null;
            while (current != null){
                if (current.val == val){
                    count++;
                    pre.next=current.next;
                }else {
                    pre = current;
                }
                current=current.next;
            }
        }
        return count;
    }

    public void reverse(){
        if (head == null)return;
        Node current = head;
        Node past = null;

        while (current != null){
            Node future = current.next;
            current.next=past;
            past=current;
            current=future;
        }
        head=past;
    }

    public void sortLinkedList(){
        if (head == null) return;
        int n = size();
        int index = 0;
        while (n != 1){
            int i = index;
            Node current = head;
            while (i != 0){
                current=current.next;
                i--;
            }
            Node large = current;
            Node small =current.next;
            while (current != null){
                current = current.next;
                if ((current != null && small != null )&& current.val < small.val){
                    small=current;
                }
            }
            if (small != null && large != null && (small.val < large.val)){
                int temp = small.val;
                small.val=large.val;
                large.val=temp;
            }
            index++;
            n--;
        }
    }

    public void keepEven(){
        if (head == null ) return;
        Node current = head;
        Node newHead = null;
        int index = 1;
        Node copy = null;

        while (current != null){
            if (index % 2 == 0) {
                Node newNode = new Node(current.val);
                if (newHead == null) {
                    newHead = newNode;
                    copy = newHead;
                }else{
                    copy.next = newNode;
                    copy=copy.next;
                }

            }
            index++;
            current=current.next;
        }
        head = newHead;
    }
    public void keepOdd() {
        if (head == null) return;
        Node newHead = null;
        Node current = head;
        Node copy = null;
        int index = 0;
        while (current != null) {
            if (index % 2 != 0) {
                Node newNode = new Node(current.val);
                
                }
            }
        }
    }

