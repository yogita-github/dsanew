package reccursion;

public interface ReccursionService {
    int factorial(int a);
    int sumTillNthNumber(int a);

}
