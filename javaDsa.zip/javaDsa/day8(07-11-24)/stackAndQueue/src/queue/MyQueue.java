package queue;

public class MyQueue <T>{
        class Node {
            T val;
            Node next;
            public Node(T v){
                this.val=v;
                next = null;
            }
        }

        private Node front = null;
        private Node back = null;

        public void offer(T v){
            Node newNode = new Node(v);
            if (front == null){
                front=newNode;
                back=newNode;
            }else{
                back.next = newNode;
                back=newNode;
            }
        }

        public T remove(){
            T ans = null;
            if (isEmpty()){
                System.out.println("Queue is empty");
            }else{
                Node p = front;
                if(front!=null) {
                    front = front.next;
                    p.next=null;
                    return p.val;
                }
            }
            return ans;
        }

        public boolean isEmpty(){
            return front == null && back == null;
        }

        public String toString(){
            Node temp = front;
            StringBuilder str = new StringBuilder("front - ");
            while (temp.next != null){
                T val = temp.val;
                if (temp != front){
                    str.append(" <-- ");
                }
                str.append(val);
                temp=temp.next;
            }

            str.append(" <-- ");
            str.append(temp.val);
            str.append(" <- rare ");
            return str.toString();
        }

}
