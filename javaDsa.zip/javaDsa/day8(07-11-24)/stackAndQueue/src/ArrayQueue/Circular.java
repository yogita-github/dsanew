package ArrayQueue;

public class Circular {
        private int front;
        private int rear;
        private int[] arr;
        private int size;

        public Circular() {
            front = -1;
            rear = -1;
            arr = new int[10];
            size = 0;
        }

        public Circular(int size) {
            front = -1;
            rear = -1;
            arr = new int[size];
            this.size = 0;
        }

        public boolean isFull() {
            return size == arr.length;
        }

        public boolean isEmpty() {
            return size == 0;
        }

        public void enqueue(int i) {
            if (!isFull()) {
                rear = (rear + 1) % arr.length;
                arr[rear] = i;
                if (front == -1) {
                    front = rear; // Set front if this is the first element
                }
                size++;
            } else {
                System.out.println("Array Queue is full");
            }
        }

        public Integer dequeue() {
            if (!isEmpty()) {
                int value = arr[front];
                front = (front + 1) % arr.length;
                size--;
                if (isEmpty()) {
                    front = -1; // Reset front and rear if the queue is now empty
                    rear = -1;
                }
                return value;
            } else {
                System.out.println("Array queue is empty");
                return null; // Return null instead of -1 for better clarity
            }
        }

        public String toString() {
            if (isEmpty()) {
                return "[]";
            }
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < size; i++) {
                sb.append(arr[(front + i) % arr.length]);
                if (i < size - 1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
            return sb.toString();
        }
    }

