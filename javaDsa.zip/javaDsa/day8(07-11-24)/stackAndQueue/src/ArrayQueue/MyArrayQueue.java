package ArrayQueue;

import java.util.Arrays;

public class MyArrayQueue {
    int front;
    int rear;
    int[] arr;

    public MyArrayQueue() {
        front = -1;
        rear = -1;
        arr = new int[10];
    }
    public MyArrayQueue(int size){
        front=-1;
        rear=-1;
        arr = new int[size];
    }
    public boolean isFull(){
        return (front== 0 && rear==arr.length - 1)|| (front == rear+1);
    }
    public boolean isEmpty(){
        return front == -1;
    }
    public void enqueue(int i){
        if(!isFull()){
            rear= (rear+1) %arr.length;
            arr[rear]=i;
        }
        else{
            System.out.println("Array Queue is full");
        }

    }
    public int dequeue(){
        if(!isEmpty()){
            int k = arr[front];
            front = (front+1)%arr.length;
            return k;
        }
        else{
            System.out.println("Array queue is empty");
        }
        return -1;
    }


    public String toString() {
        return Arrays.toString(arr) ;
    }
}
